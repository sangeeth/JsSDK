package net.sangeeth.jssdk.jsc;

import java.util.Stack;

public class ScopeBuilder extends JSParserAdapter {
	private Stack<Scope> scopeStack;
	public ScopeBuilder() {
		
	}
	
	public void finished(boolean success) {
		// TODO Auto-generated method stub
		
	}

	public void started() {
		
		
	}

	public void consumedToken(Token token) {
		// TODO Auto-generated method stub
		
	}

	public void beginBlock() {
		// TODO Auto-generated method stub
		
	}

	public void endBlock() {
		// TODO Auto-generated method stub
		
	}

	public void definedSymbol(Symbol symbol) {
		// TODO Auto-generated method stub
		
	}

	public void declaredDirective(DirectiveRef directive) {
		// TODO Auto-generated method stub
		
	}

}
