package net.sangeeth.jssdk.jsc;

public enum SymbolType {
	VARIABLE,
	FUNCTION,
	DIRECTIVEDEF
}
