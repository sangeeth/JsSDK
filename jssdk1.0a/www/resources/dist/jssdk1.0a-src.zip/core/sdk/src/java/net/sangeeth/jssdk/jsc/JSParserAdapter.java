package net.sangeeth.jssdk.jsc;

public class JSParserAdapter implements JSParserListener {

	public void beginBlock() {
		// TODO Auto-generated method stub
		
	}

	public void consumedToken(Token token) {
		// TODO Auto-generated method stub
		
	}

	public void declaredDirective(DirectiveRef directive) {
		// TODO Auto-generated method stub
		
	}

	public void definedSymbol(Symbol symbol) {
		// TODO Auto-generated method stub
		
	}

	public void endBlock() {
		// TODO Auto-generated method stub
		
	}

	public void finished(boolean success) {
		// TODO Auto-generated method stub
		
	}

	public void started() {
		// TODO Auto-generated method stub
		
	}

	public void beginScope() {
		// TODO Auto-generated method stub
		
	}

	public void endScope() {
		// TODO Auto-generated method stub
		
	}

}
